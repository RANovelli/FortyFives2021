from django.apps import AppConfig


class SinglesConfig(AppConfig):
    name = 'singles'
